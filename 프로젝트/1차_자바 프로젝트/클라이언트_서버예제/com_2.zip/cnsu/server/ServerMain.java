package com.cnsu.server;

import com.cnsu.server.controller.ServerManager;

public class ServerMain {

    public static void main(String[] args) {
        ServerManager svrManager = new ServerManager();


    }
}
