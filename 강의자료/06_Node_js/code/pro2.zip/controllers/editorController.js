const sanitizeHtml = require('sanitize-html');
const Editor = require('../models/editorModel');

const SANITIZE = {
  allowedTags: [...sanitizeHtml.defaults.allowedTags, 'img','h1','h2','span'],
  allowedAttributes: {
    ...sanitizeHtml.defaults.allowedAttributes,
    img: ['src','alt','width','height','style'],
    span: ['style'],
    p: ['style'],
    div: ['style'],
  },
  allowedSchemes: ['data','http','https'],
};

exports.createPost = async (req, res) => {
  try {
    const { title = '', content = '', hashtag = '', user_id = 1 } = req.body || {};
    const t = String(title).trim();
    const c = String(content).trim();

    if (!t || !c || c === '<p><br></p>') {
      return res.status(400).json({ error: 'title, content는 필수입니다.' });
    }

    const safeHtml = sanitizeHtml(c, SANITIZE);
    const thumbnailUrl = req.file ? `/uploads/${req.file.filename}` : null;

    const id = await Editor.create({
      user_id: Number(user_id) || 1,
      title: t,
      content: safeHtml,
      hashtag: String(hashtag || '').trim(),
      thumbnail: thumbnailUrl,
    });

    return res.status(201).json({ ok: true, id });
  } catch (err) {
    console.error('[POST /editor/posts] 실패', {
      msg: err.message,
      stack: err.stack,
      bodyKeys: Object.keys(req.body || {}),
      hasFile: !!req.file,
    });
    return res.status(500).json({ error: '글 저장 실패', detail: err.message });
  }
};

exports.getPostById = async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ error: 'invalid id' });
    const row = await Editor.findById(id);
    if (!row) return res.status(404).json({ error: 'not found' });
    return res.json({ ok: true, post: row });
  } catch (err) {
    console.error('[GET /posts/:id] 실패', err);
    return res.status(500).json({ error: '조회 실패', detail: err.message });
  }
};

exports.preview = async (req, res) => {
  try {
    const id = Number(req.params.id);
    const post = await Editor.findById(id);
    if (!post) return res.status(404).send('not found');
    res.send(`
      <!doctype html><meta charset="utf-8">
      <h1>${post.title}</h1>
      ${post.thumbnail ? `<p><img src="${post.thumbnail}" style="max-width:640px;width:100%"></p>` : ''}
      <article>${post.content}</article>
      <hr>
      <small>#${post.hashtag || ''} · ${post.created_at}</small>
    `);
  } catch (e) {
    res.status(500).send('preview error: ' + e.message);
  }
};
