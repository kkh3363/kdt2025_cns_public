// controllers/usersController.js

// [ADD] mysql2/promise 풀 사용
const db = require('../config/db');
const User = require('../models/usersModel'); // 기존 모델

/* =========================
 *  아이디 중복 확인 (기존)
 * ========================= */
exports.checkId = async (req, res) => {
  try {
    const user_login_id = (req.query.sin_ID || '').trim();
    console.log("sdkjfl");
    
    if (!user_login_id) {
      return res.status(400).json({ error: '아이디가 필요합니다.' });
    }

    const exist = await User.findByLoginId(user_login_id);
    if (exist) {
      console.log("이미 있음");
      return res.json({ available: false, message: '이미 사용 중인 아이디입니다.' });
    }
    return res.json({ available: true, message: '사용 가능한 아이디입니다.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: '아이디 확인 실패' });
  }
};

/* =========================
 *  이메일 중복 확인 (기존)
 * ========================= */
exports.checkEmail = async (req, res) => {
  try {
    const email = String(req.query.sin_email || '').trim();
    if (!email) {
      return res.status(400).json({ error: '이메일이 필요합니다.' });
    }

    const exist = await User.findByEmail(email);
    if (exist) {
      return res.json({ available: false, message: '이미 사용 중인 이메일입니다.' });
    }
    return res.json({ available: true, message: '사용 가능한 이메일입니다.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: '이메일 확인 실패' });
  }
};

/* =========================
 *  회원가입 (기존)
 * ========================= */
exports.register = async (req, res) => {
  try {
    const username      = (req.body.username || '').trim();
    const user_login_id = (req.body.user_login_id || '').trim();
    const email         = String(req.body.email || '').trim();
    const password      = String(req.body.password || '');

    if (!username || !user_login_id || !email || !password) {
      return res.status(400).send('필수값(username, user_login_id, email, password)이 필요합니다.');
    }

    if (password.length < 4) {
      return res.status(400).send('비밀번호는 최소 4자 이상이어야 합니다.');
    }
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailOk) {
      return res.status(400).send('이메일 형식이 올바르지 않습니다.');
    }

    await User.createUser({
      username,
      user_login_id,
      email,
      password,
      profile_img_url: req.body.profile_img_url || null,
    });

    return res.redirect('/login.html');
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') {
      return res.status(409).send('이미 존재하는 아이디 또는 이메일입니다.');
    }
    console.error(err);
    return res.status(500).send('회원가입 실패');
  }
};

/* =========================
 *  [ADD] 현재 로그인 사용자 조회
 *  - edit-profile.html 자동 채움
 * ========================= */
exports.getMe = async (req, res) => {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ message: '로그인이 필요합니다.' });
  }
  const u = req.session.user;
  // 프론트는 userId / email 필드를 사용
  return res.json({
    userId: u.user_login_id || u.loginId || u.id || '',
    email:  u.email || ''
  });
};

/* =========================
 *  [ADD] 프로필 수정 (아이디/이메일/비밀번호)
 *  - 비밀번호 규칙 없음: 프론트에서 일치만 확인
 *  - 세션에 PK가 없으면 user_login_id/email로 PK를 조회해 복구
 * ========================= */
exports.updateProfile = async (req, res) => {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ message: '로그인이 필요합니다.' });
  }

  const { userId, email, password } = req.body;
  const sessionUser = req.session.user;

  try {
    const fields = [];
    const values = [];

    if (userId) {
      fields.push('user_login_id = ?');
      values.push(userId);
    }
    if (email) {
      fields.push('email = ?');
      values.push(email);
    }
    if (password) {
      // 요청대로 규칙 없이 그대로 저장 (실서비스는 bcrypt 권장)
      fields.push('password = ?');
      values.push(password);
    }

    if (fields.length === 0) {
      return res.json({ ok: true, message: '변경 사항이 없습니다.' });
    }

    // [ADD] PK 확보: 세션에서 우선, 없으면 DB로 복구
    let pk = sessionUser.user_id ?? sessionUser.id ?? null;
    if (!pk) {
      // 세션에 PK가 없는 경우, login_id 또는 email로 조회
      const [rows] = await db.execute(
        `SELECT user_id FROM users WHERE user_login_id = ? OR email = ? LIMIT 1`,
        [sessionUser.user_login_id || null, sessionUser.email || null]
      );
      if (rows && rows.length) {
        pk = rows[0].user_id;
        // 세션에도 심어 둠
        sessionUser.user_id = pk;
        req.session.user = sessionUser;
      }
    }

    if (!pk) {
      return res.status(400).json({ message: '세션에 사용자 ID가 없습니다.' });
    }

    values.push(pk);
    const sql = `UPDATE users SET ${fields.join(', ')} WHERE user_id = ?`;

    // 디버깅 로그 (필요 시 주석 해제)
    // console.log('실행할 SQL:', sql, values);

    await db.execute(sql, values);

    // 세션 최신화
    if (userId)   sessionUser.user_login_id = userId;
    if (email)    sessionUser.email = email;
    if (password) sessionUser.password = password;
    req.session.user = sessionUser;

    return res.json({ ok: true });
  } catch (err) {
    console.error('updateProfile error:', err);
    return res.status(500).json({ message: '프로필 업데이트 실패' });
  }
};
