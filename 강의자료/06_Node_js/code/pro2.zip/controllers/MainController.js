// 메인 화면
const Main = require('../models/MainModel');

exports.sliderTop10WithImage7d = async (_req, res) => {
  try {
    const items = await Main.sliderTop10WithImage7d();
    return res.json({ ok: true, items });
  } catch (err) {
    console.error('[GET /api/main/slider] error', err);
    return res.status(500).json({ ok: false, message: '슬라이더 데이터 실패' });
  }
};

exports.weeklyTop = async (_req, res) => {
  try {
    const items = await Main.weeklyTop10();
    return res.json({ ok: true, items });
  } catch (err) {
    console.error('[GET /api/main/weekly] error', err);
    return res.status(500).json({ ok: false, message: '주간 인기 실패' });
  }
};

exports.dailyTop5 = async (_req, res) => {
  try {
    const items = await Main.dailyTop5();
    return res.json({ ok: true, items });
  } catch (err) {
    console.error('[GET /api/main/daily] error', err);
    return res.status(500).json({ ok: false, message: '일간 인기 실패' });
  }
};

exports.sectionsBundle = async (_req, res) => {
  try {
    const [slider, weekly, daily] = await Promise.all([
      Main.sliderTop10WithImage7d(),
      Main.weeklyTop10(),
      Main.dailyTop5(),
    ]);
    return res.json({ ok: true, slider, weekly, daily });
  } catch (err) {
    console.error('[GET /api/main/sections] error', err);
    return res.status(500).json({ ok: false, message: '메인 섹션 실패' });
  }
};
