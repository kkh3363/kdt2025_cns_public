//화원정보 수정
const crypto = require('crypto');
const User = require('../models/edit-profileModel');

function sha256(txt) {
  return crypto.createHash('sha256').update(String(txt), 'utf8').digest('hex');
}

exports.me = async (req, res) => {
  try {
    const sessUser = req.session?.user;
    if (!sessUser) return res.status(401).json({ ok: false, message: '로그인이 필요합니다.' });

    const me = await User.findById(sessUser.id || sessUser.user_id);
    if (!me) return res.status(404).json({ ok: false, message: '사용자를 찾을 수 없습니다.' });

    return res.json({
      ok: true,
      id: me.id,
      userId: me.login_id,
      email: me.email,
      nickname: me.nickname || '',
    });
  } catch (err) {
    console.error('[GET /api/me] error', err);
    return res.status(500).json({ ok: false, message: '내 정보 조회 실패' });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const sessUser = req.session?.user;
    if (!sessUser) return res.status(401).json({ ok: false, message: '로그인이 필요합니다.' });

    const email    = String(req.body.email || '').trim();
    const nickname = String(req.body.nickname || '').trim();
    const pw       = String(req.body.password || '').trim();

    if (!email) return res.status(400).json({ ok: false, message: '이메일은 필수입니다.' });

    const me = await User.findById(sessUser.id || sessUser.user_id);
    if (!me) return res.status(404).json({ ok: false, message: '사용자를 찾을 수 없습니다.' });

    if (email !== me.email) {
      const exists = await User.findByEmail(email);
      if (exists) return res.status(409).json({ ok: false, message: '이미 사용 중인 이메일입니다.' });
    }

    const updatePayload = {
      email,
      nickname,
    };
    if (pw) updatePayload.password_hash = sha256(pw);

    await User.updateById(me.id, updatePayload);

    req.session.user = {
      ...(req.session.user || {}),
      id: me.id,
      user_id: me.id,
      loginId: me.login_id,
      email,
      nickname,
    };

    return res.json({ ok: true, message: '프로필이 수정되었습니다.' });
  } catch (err) {
    console.error('[PATCH /api/profile] error', err);
    return res.status(500).json({ ok: false, message: '수정 실패', detail: err.message });
  }
};
