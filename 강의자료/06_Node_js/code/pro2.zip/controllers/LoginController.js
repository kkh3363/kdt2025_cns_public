const Users = require('../models/LoginModel');

exports.login = async (req, res) => {
  try {
    const user_login_id = (req.body.user_login_id || '').trim();
    const password      = String(req.body.password || '');

    if (!user_login_id || !password) {
      return res.redirect('/login.html?error=아이디와 비밀번호를 입력해주세요.');
    }

    const user = await Users.findByLoginId(user_login_id);
    if (!user) {
      return res.redirect('/login.html?error=존재하지 않는 아이디입니다.');
    }
    if (user.password !== password) {
      return res.redirect('/login.html?error=비밀번호가 올바르지 않습니다.');
    }

    req.session.regenerate((err) => {
      if (err) {
        console.error('session regenerate error:', err);
        return res.redirect('/login.html?error=세션 오류가 발생했습니다.');
      }

      req.session.user = {
        id:       user.user_id,
        username: user.username,
        loginId:  user.user_login_id,
        email:    user.email || null,
        nickname: user.nickname || null,
      };

      req.session.save(() => {
        return res.redirect('/?login=success');
      });
    });
  } catch (err) {
    console.error(err);
    return res.redirect('/login.html?error=로그인 실패');
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.set('Cache-Control', 'no-store');
    res.clearCookie('connect.sid');
    res.json({ ok: true });
  });
};

exports.me = (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.session && req.session.user) {
    return res.json({ ok: true, user: req.session.user });
  }
  return res.json({ ok: false, user: null });
};
