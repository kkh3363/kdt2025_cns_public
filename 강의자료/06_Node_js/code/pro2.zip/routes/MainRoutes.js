// 메인 화면
const express = require('express');
const router = express.Router();
const main = require('../controllers/MainController');

router.get('/api/main/slider',   main.sliderTop10WithImage7d);
router.get('/api/main/weekly',   main.weeklyTop);
router.get('/api/main/daily',    main.dailyTop5);
router.get('/api/main/sections', main.sectionsBundle);

module.exports = router;