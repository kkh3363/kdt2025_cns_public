const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/edit-profileController');

router.get('/api/me', ctrl.me);

router.patch('/api/profile', ctrl.updateProfile);

module.exports = router;
