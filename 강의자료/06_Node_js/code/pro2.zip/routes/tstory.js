// routes/usersRoutes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/usersController');

router.get('/check-id',    userController.checkId);
router.get('/check-email', userController.checkEmail);
router.post('/register',   userController.register);

// [ADD] 프로필 관련 API
router.get('/api/me',      userController.getMe);
router.patch('/api/profile', userController.updateProfile);

module.exports = router;