const path = require('path');
const express = require('express');
const multer  = require('multer');
const editor  = require('../controllers/editorController');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.jpg').toLowerCase();
    cb(null, `${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`);
  },
});
const upload = multer({ storage });

router.post('/editor/posts', upload.single('thumbnail'), editor.createPost);

router.get('/posts/:id', editor.getPostById);

router.get('/posts/:id/view', editor.preview);

router.post('/debug/echo', upload.single('thumbnail'), (req, res) => {
  res.json({
    ok: true,
    body: req.body,
    hasFile: !!req.file,
    file: req.file && {
      originalname: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      filename: req.file.filename,
    }
  });
});

module.exports = router;
