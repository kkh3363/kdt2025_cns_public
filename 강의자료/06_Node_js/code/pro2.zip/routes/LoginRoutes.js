const express = require('express');
const router = express.Router();
const L = require('../controllers/LoginController');

router.post('/auth/login', L.login);
router.post('/auth/logout', L.logout);
router.get('/auth/me', L.me);

module.exports = router;
