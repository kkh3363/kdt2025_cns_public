// routes/usersRoutes.js
const express = require('express');
const router = express.Router();
const memberController = require('../controllers/memberController');

router.route('/login')
    .get( (req,res)=>{
            message='';
            res.render("member/login", {message});
        })
    .post(memberController.login);
    
router.route('/logout')
    .get( memberController.logout);

router.get('/signup', (req,res)=>{
    res.render("member/signup");
});

//router.get('/check-id',    userController.checkId);
//router.get('/check-email', userController.checkEmail);
//router.post('/register',   userController.register);

// [ADD] 프로필 관련 API
//router.get('/api/me',      userController.getMe);
//router.patch('/api/profile', userController.updateProfile);

module.exports = router;