const db = require('../config/db');

async function createUser({ username, user_login_id, email, password, profile_img_url = null }) {
  const sql = `
    INSERT INTO users (username, user_login_id, email, password, profile_img_url)
    VALUES (?, ?, ?, ?, ?)
  `;
  const [r] = await db.execute(sql, [
    username,
    user_login_id,
    email,
    password,
    profile_img_url
  ]);
  return r.insertId;
}

async function findByEmail(email) {
  const [rows] = await db.execute(`SELECT * FROM users WHERE email = ? LIMIT 1`, [email]);
  return rows[0] || null;
}

async function findByLoginId(user_login_id) {
  const [rows] = await db.execute(`SELECT * FROM users WHERE user_login_id = ? LIMIT 1`, [user_login_id]);
  return rows[0] || null;
}

module.exports = { createUser, findByEmail, findByLoginId };