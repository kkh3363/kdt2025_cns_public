const pool = require('../config/db');

exports.create = async ({ user_id, title, content, hashtag, thumbnail, category_code }) => {
  const sql = `
    INSERT INTO posts (user_id, title, category_code, content, hashtag, thumbnail)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  const params = [
    user_id,
    title,
    category_code || null,
    content,
    hashtag || null,
    thumbnail || null,
  ];
  const [rs] = await pool.execute(sql, params);
  return rs.insertId;
};

exports.findById = async (post_id) => {
  const sql = `
    SELECT post_id, user_id, title, category_code, content, views, hashtag, thumbnail, created_at
      FROM posts
     WHERE post_id = ?
  `;
  const [rows] = await pool.execute(sql, [post_id]);
  return rows[0] || null;
};

exports.increaseViews = async (post_id) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.execute(`UPDATE posts SET views = views + 1 WHERE post_id = ?`, [post_id]);

    try {
      await conn.execute(`
        INSERT INTO post_views_daily (post_id, ymd, views)
        VALUES (?, CURRENT_DATE, 1)
        ON DUPLICATE KEY UPDATE views = views + 1
      `, [post_id]);
    } catch (e) {
      console.error(e);
    }

    await conn.commit();
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
};

exports.search = async ({ q, page = 1, size = 10 }) => {
  const limit  = Math.min(50, Math.max(1, Number(size)));
  const offset = (Math.max(1, Number(page)) - 1) * limit;

  if (q && q.trim()) {
    try {
      const sql = `
        SELECT post_id, title, category_code, hashtag, thumbnail, created_at, views,
               LEFT(REPLACE(REPLACE(content,'<',' <'),'>','> '), 300) AS snippet
          FROM posts
         WHERE MATCH(title, content) AGAINST(? IN NATURAL LANGUAGE MODE)
            OR category_code LIKE ?
         ORDER BY post_id DESC
         LIMIT ?, ?
      `;
      const [rows] = await pool.execute(sql, [q, `%${q}%`, offset, limit]);
      return rows;
    } catch {
      const like = `%${q}%`;
      const sql = `
        SELECT post_id, title, category_code, hashtag, thumbnail, created_at, views,
               LEFT(REPLACE(REPLACE(content,'<',' <'),'>','> '), 300) AS snippet
          FROM posts
         WHERE title LIKE ? OR content LIKE ? OR category_code LIKE ?
         ORDER BY post_id DESC
         LIMIT ?, ?
      `;
      const [rows] = await pool.execute(sql, [like, like, like, offset, limit]);
      return rows;
    }
  }

  const sql = `
    SELECT post_id, title, category_code, hashtag, thumbnail, created_at, views,
           LEFT(REPLACE(REPLACE(content,'<',' <'),'>','> '), 300) AS snippet
      FROM posts
     ORDER BY post_id DESC
     LIMIT ?, ?
  `;
  const [rows] = await pool.execute(sql, [offset, limit]);
  return rows;
};
