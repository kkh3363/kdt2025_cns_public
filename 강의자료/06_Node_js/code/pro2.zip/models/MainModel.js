// 메인 화면
const pool = require('../config/db');

function hasThumbClause(alias = 'p') {
  return `${alias}.Thumbnail IS NOT NULL AND ${alias}.Thumbnail <> ''`;
}

// 슬라이드 사진 5개
exports.sliderTop10WithImage7d = async () => {
  const sql = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      SUM(v.views) AS v7
    FROM post_views_daily v
    JOIN posts p ON p.post_id = v.post_id
    WHERE v.ymd >= (CURRENT_DATE - INTERVAL 6 DAY)
      AND ${hasThumbClause('p')}
    GROUP BY p.post_id, p.title, p.Thumbnail, p.category
    ORDER BY v7 DESC, p.post_id DESC
    LIMIT 5
  `;
  try {
    const [rows] = await pool.execute(sql);
    if (rows.length > 0) return rows;
  } catch (e) {
    console.warn('[sliderTop10WithImage7d] primary query failed -> fallback:', e.message);
  }

  const fallback = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      p.views     AS v7
    FROM posts p
    WHERE p.created_at >= NOW() - INTERVAL 7 DAY
      AND ${hasThumbClause('p')}
    ORDER BY p.views DESC, p.post_id DESC
    LIMIT 5
  `;
  const [rows2] = await pool.execute(fallback);
  return rows2;
};

// 일주일 TOP글 10개
exports.weeklyTop10 = async () => {
  const sql = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      SUM(v.views) AS v7
    FROM post_views_daily v
    JOIN posts p ON p.post_id = v.post_id
    WHERE v.ymd >= (CURRENT_DATE - INTERVAL 6 DAY)
    GROUP BY p.post_id, p.title, p.Thumbnail, p.category
    ORDER BY v7 DESC, p.post_id DESC
    LIMIT 10
  `;
  try {
    const [rows] = await pool.execute(sql);
    if (rows.length > 0) return rows;
  } catch (e) {
    console.warn('[weeklyTop10] primary query failed -> fallback:', e.message);
  }

  const fallback = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      p.views     AS v7
    FROM posts p
    WHERE p.created_at >= NOW() - INTERVAL 7 DAY
    ORDER BY p.views DESC, p.post_id DESC
    LIMIT 10
  `;
  const [rows2] = await pool.execute(fallback);
  return rows2;
};

//오늘TOP 5개
exports.dailyTop5 = async () => {
  const sql = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      v.views     AS today
    FROM post_views_daily v
    JOIN posts p ON p.post_id = v.post_id
    WHERE v.ymd = CURRENT_DATE
    GROUP BY p.post_id, p.title, p.Thumbnail, p.category, v.views
    ORDER BY today DESC, p.post_id DESC
    LIMIT 5
  `;
  try {
    const [rows] = await pool.execute(sql);
    if (rows.length > 0) return rows;
  } catch (e) {
    console.warn('[dailyTop5] primary query failed -> fallback:', e.message);
  }

  const fallback = `
    SELECT
      p.post_id,
      p.title,
      p.Thumbnail AS thumbnail,
      p.category  AS category,
      p.views     AS today
    FROM posts p
    WHERE DATE(p.created_at) = CURRENT_DATE
    ORDER BY today DESC, p.post_id DESC
    LIMIT 5
  `;
  const [rows2] = await pool.execute(fallback);
  return rows2;
};