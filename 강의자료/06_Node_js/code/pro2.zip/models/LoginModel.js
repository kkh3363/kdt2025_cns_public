// models/LoginModel.js
const db = require('../config/db'); // 경로 맞춰주세요 (config/db.js)

async function findByLoginId(user_login_id) {
  const [rows] = await db.execute(
    'SELECT * FROM users WHERE user_login_id = ? LIMIT 1',
    [user_login_id]
  );
  return rows[0] || null;
}

// ❗객체 형태로 내보냄 → 라우터에서 LoginModel.findByLoginId 사용 가능
module.exports = { findByLoginId };
