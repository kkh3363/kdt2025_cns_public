//화원정보 수정
const pool = require('../config/db');

exports.findById = async (id) => {
  const sql = `SELECT id, login_id, email, password_hash, nickname FROM users WHERE id = ? LIMIT 1`;
  const [rows] = await pool.execute(sql, [id]);
  return rows[0] || null;
};

exports.findByEmail = async (email) => {
  const sql = `SELECT id, login_id, email, password_hash, nickname FROM users WHERE email = ? LIMIT 1`;
  const [rows] = await pool.execute(sql, [email]);
  return rows[0] || null;
};

exports.updateById = async (id, fields) => {
  const sets = [];
  const vals = [];
  for (const [k, v] of Object.entries(fields)) {
    sets.push(`${k} = ?`);
    vals.push(v);
  }
  if (!sets.length) return;
  const sql = `UPDATE users SET ${sets.join(', ')} WHERE id = ?`;
  vals.push(id);
  await pool.execute(sql, vals);
};