const path = require('path');
const fs = require('fs');
const express = require('express');
const session = require('express-session');
const dotenv = require('dotenv');
const multer = require('multer');
const morgan = require('morgan');
const cors = require('cors');
const ejs = require('ejs');

dotenv.config();
const app = express();

const isProd   = process.env.NODE_ENV === 'production';
const useHttps = process.env.USE_HTTPS === '1';

const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

app.set('view engine','ejs');
app.set('views', './views');
app.use(express.static("./public"));

app.use(express.static(path.join(__dirname, 'html')));
app.use('/uploads', express.static(uploadsDir));

app.use(cors());
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

if (isProd && useHttps) app.set('trust proxy', 1);
app.use(session({
  secret: process.env.SESSION_SECRET || 'default-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: false,
    sameSite: isProd && useHttps ? 'none' : 'lax',
    maxAge: 1000 * 60 * 60,
  },
}));

app.get('/', (req, res) => {
  //res.sendFile(path.join(__dirname, 'html', 'Main.html'));
  res.render('index');
});

app.get('/mypage', (req, res) => {
  if (req.session && req.session.user) {
    return res.sendFile(path.join(__dirname, 'html', 'myPage.html'));
  }
  return res.redirect('/login.html');
});

app.get('/myPage', (_req, res) => res.redirect('/mypage'));
app.get('/editor',      (_req, res) => res.sendFile(path.join(__dirname, 'html', 'editor.html')));
//app.get('/login',       (_req, res) => res.sendFile(path.join(__dirname, 'html', 'login.html')));
app.get('/signup',      (_req, res) => res.sendFile(path.join(__dirname, 'html', 'signUp.html')));
app.get('/information', (_req, res) => res.sendFile(path.join(__dirname, 'html', 'information.html')));
app.get('/search',      (_req, res) => res.sendFile(path.join(__dirname, 'html', 'search.html')));

const mainRoutes    = require('./routes/MainRoutes');
const editorRoutes  = require('./routes/editorRoutes');
const loginRoutes   = require('./routes/LoginRoutes');
const usersRoutes   = require('./routes/usersRoutes');
const profileRoutes = require('./routes/edit-profileRoutes');

app.use('/', mainRoutes);
app.use('/', editorRoutes);
app.use('/', loginRoutes);
app.use('/', usersRoutes);
app.use('/', profileRoutes);

const upload = multer({ dest: uploadsDir });
app.post('/upload', upload.single('image'), (req, res) => {
  if (req.file) return res.json({ ok: true, file: req.file });
  res.status(400).json({ error: '파일 업로드 실패' });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

app.get('/auth/me', (req, res) => {
  res.set('Cache-Control', 'no-store'); // 캐시 금지
  res.json({
    ok: !!(req.session && req.session.user),
    user: req.session?.user || null
  });
});

function logoutHandler(req, res) {
  req.session?.destroy(() => {
    res.set('Cache-Control', 'no-store');
    res.json({ ok: true });
  });
}
app.use('/member', require('./routes/memberRoutes') );
app.post('/logout', logoutHandler);
app.post('/api/logout', logoutHandler);
app.post('/auth/logout', logoutHandler);

app.use((err, _req, res, _next) => {
  console.error('[UNCAUGHT ERROR]', err);
  res.status(500).json({ error: '서버 오류', detail: err.message });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Travel Log server listening on http://localhost:${PORT}`);
});
