 const FALLBACK_IMG = 'https://via.placeholder.com/120x90?text=No+Image';

    const fmtNum = (n) => (n == null || isNaN(n)) ? '0' : Number(n).toLocaleString('ko-KR');
    const safe   = (s) => String(s ?? '')
      .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
      .replaceAll('"','&quot;').replaceAll("'",'&#39;');
    const thumb  = (t) => (t && String(t).trim()) ? t : FALLBACK_IMG;

    const actionsEl = document.getElementById('actions');

    function renderLoggedOut(){
      actionsEl.innerHTML = `
        <a href="login.html" class="btn">로그인</a>
        <a href="/editor" class="btn btn-primary">글쓰기</a>
      `;
    }

    function renderLoggedIn(user){
      actionsEl.innerHTML = `
        <a href="/mypage" class="btn">마이페이지</a>
        <button type="button" id="logoutBtn" class="btn">로그아웃</button>
        <a href="/editor" class="btn btn-primary">글쓰기</a>
      `;
      document.getElementById('logoutBtn').addEventListener('click', async ()=>{
        for (const ep of ['/logout','/api/logout','/auth/logout']) {
          try { const r = await fetch(ep, { method:'POST', credentials:'include' }); if (r.ok) break; } catch {}
        }
        location.href = '/';
      });
    }

     async function checkAuth(){
    //   try {
    //     const r = await fetch('/auth/me?ts=' + Date.now(), {
    //       method: 'GET',
    //       credentials: 'include',
    //       headers: { 'Cache-Control': 'no-cache' }
    //     });
    //     const d = await r.json();
    //     if (d?.ok && d.user) renderLoggedIn(d.user);
    //     else renderLoggedOut();
    //   } catch {
    //     renderLoggedOut();
    //   }
     }

    document.getElementById('search-btn').addEventListener('click', ()=>{
      const q = document.getElementById('search-input').value.trim();
      if (q) location.href = 'search.html?query=' + encodeURIComponent(q);
    });

    async function loadSections(){
      try {
        const r = await fetch('/api/main/sections', { credentials:'include' });
        if (r.ok) {
          const d = await r.json();
          return { slider: d.slider||[], weekly: d.weekly||[], daily: d.daily||[] };
        }
      } catch {}
      const [s, w, d] = await Promise.allSettled([
        fetch('/api/main/slider').then(r=>r.ok?r.json():{items:[]}).catch(()=>({items:[]})),
        fetch('/api/main/weekly').then(r=>r.ok?r.json():{items:[]}).catch(()=>({items:[]})),
        fetch('/api/main/daily').then(r=>r.ok?r.json():{items:[]}).catch(()=>({items:[]})),
      ]);
      return {
        slider: s.value?.items || [],
        weekly: w.value?.items || [],
        daily : d.value?.items || []
      };
    }

    let cur = 0, timer = null;
    function renderSlider(list){
      const sliderEl = document.getElementById('slider');
      const slidesEl = document.getElementById('slides');
      const dotsEl   = document.getElementById('dots');

      const items = (list || []).filter(p=>!!p.thumbnail).slice(0,5);
      if (!items.length) { sliderEl.style.display = 'none'; return; }

      slidesEl.innerHTML = items.map(p=>`
        <a class="slide" href="search.html?query=${encodeURIComponent(p.post_id)}"
           style="background-image:url('${thumb(p.thumbnail)}')">
          <div class="caption">
            <h3>${safe(p.title)}</h3>
            <p>최근 7일 조회수: ${fmtNum(p.v7 ?? p.views)}</p>
          </div>
        </a>
      `).join('');

      dotsEl.innerHTML = items.map((_,i)=>`
        <div class="dot${i===0?' active':''}" data-i="${i}"></div>
      `).join('');

      const count = items.length;
      const go = (idx)=>{
        cur = (idx + count) % count;
        slidesEl.style.transform = `translateX(-${cur*100}%)`;
        dotsEl.querySelectorAll('.dot').forEach((d,i)=>d.classList.toggle('active', i===cur));
      };

      document.getElementById('prev').onclick = ()=>go(cur-1);
      document.getElementById('next').onclick = ()=>go(cur+1);
      dotsEl.querySelectorAll('.dot').forEach(d=>d.addEventListener('click',()=>go(+d.dataset.i)));

      const start=()=>{ stop(); if (count>1) timer=setInterval(()=>go(cur+1), 4000); };
      const stop =()=>{ if (timer) { clearInterval(timer); timer=null; } };
      sliderEl.addEventListener('mouseenter', stop);
      sliderEl.addEventListener('mouseleave', start);
      start();
    }

    function renderWeekly(list){
      const box = document.getElementById('weeklyList');
      if (!list?.length) { box.innerHTML = `<p class="muted">최근 7일 인기 글이 없습니다.</p>`; return; }
      box.innerHTML = list.slice(0,10).map(p=>`
        <article class="post-item" data-id="${p.post_id}">
          <img src="${thumb(p.thumbnail)}" alt="${safe(p.title)}" onerror="this.src='${FALLBACK_IMG}'" />
          <div class="info">
            <h3>${safe(p.title)}</h3>
            <p class="muted">최근 7일 조회수: ${fmtNum(p.v7 ?? p.views)}</p>
          </div>
        </article>
      `).join('');
      box.querySelectorAll('.post-item').forEach(el=>{
        el.addEventListener('click', ()=>location.href='search.html?query='+encodeURIComponent(el.dataset.id));
      });
    }

    function renderDaily(list){
      const box = document.getElementById('dailyList');
      if (!list?.length) { box.innerHTML = `<p class="muted">오늘 인기 글이 없습니다.</p>`; return; }
      box.innerHTML = list.slice(0,5).map(p=>`
        <article class="post-item" data-id="${p.post_id}">
          <img src="${thumb(p.thumbnail)}" alt="${safe(p.title)}" onerror="this.src='${FALLBACK_IMG}'" />
          <div class="info">
            <h3>${safe(p.title)}</h3>
            <p class="muted">오늘 조회수: ${fmtNum(p.today ?? p.views)}</p>
          </div>
        </article>
      `).join('');
      box.querySelectorAll('.post-item').forEach(el=>{
        el.addEventListener('click', ()=>location.href='search.html?query='+encodeURIComponent(el.dataset.id));
      });
    }

     (async function init(){
    //  // await checkAuth();
       const { slider, weekly, daily } = await loadSections();
       renderSlider(slider);
    //   renderWeekly(weekly);
    //   renderDaily(daily);
     })();