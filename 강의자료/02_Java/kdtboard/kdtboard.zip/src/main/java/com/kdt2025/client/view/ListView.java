package com.kdt2025.client.view;

import com.kdt2025.client.controller.ClientManager;
import com.kdt2025.client.handler.ListActionHandler;
import com.kdt2025.common.dto.PostDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ListView extends JPanel{
    private DefaultTableModel model;
    private JTable table;
    private List<PostDto> posts = new ArrayList<>();
    public ClientManager clientManager;
    public JButton btnAdd;
    public JButton btnView;
    public JButton btnDelete;

    public ListView(ClientManager clientManager) {
        this.clientManager= clientManager;
        // 테이블 모델과 JTable 생성
        model = new DefaultTableModel(new Object[]{"번호", "제목", "작성자", "날짜"}, 0);
        table = new JTable(model);
        table.setFillsViewportHeight(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(600,300));
        // 버튼들
         btnAdd = new JButton("글쓰기");
         btnView = new JButton("상세보기");
         btnDelete = new JButton("삭제");

        JPanel btnPanel = new JPanel();
        btnPanel.add(btnAdd);
        btnPanel.add(btnView);
        btnPanel.add(btnDelete);
        btnAdd.addActionListener(new ListActionHandler(this));
        btnView.addActionListener(new ListActionHandler(this));
        add(scroll, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

//        btnAdd.addActionListener(e -> showWriteDialog());
//        btnView.addActionListener(e -> showViewDialog());
//        btnDelete.addActionListener(e -> deletePost());

        refreshTable();
    }
    private void refreshTable() {
        model.setRowCount(0);
        for (PostDto p : posts) {
            model.addRow(new Object[]{p.getId(), p.getTitle(), p.getWriter(), p.getDate()} );
        }
    }
}
