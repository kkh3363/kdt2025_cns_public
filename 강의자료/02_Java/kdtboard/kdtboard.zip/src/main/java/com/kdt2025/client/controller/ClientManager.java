package com.kdt2025.client.controller;

import com.kdt2025.client.view.ClientMainView;

import javax.swing.*;

public class ClientManager extends  Thread{
    public ClientMainView clientMainView;
    public ClientManager() {
        clientMainView = new ClientMainView(this);
        SwingUtilities.invokeLater(() -> clientMainView.setVisible(true));

    }

    @Override
    public void run() {
        super.run();
    }
    public void changePanel(String strPanel){
        clientMainView.changePanel(strPanel);
        //repaint();
    }
}
