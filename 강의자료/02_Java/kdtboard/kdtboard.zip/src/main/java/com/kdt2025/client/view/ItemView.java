package com.kdt2025.client.view;

import com.kdt2025.client.controller.ClientManager;

import javax.swing.*;
import java.awt.*;

public class ItemView extends JPanel {
    ClientManager clientManager;
    public ItemView(ClientManager clientManager) {
        this.clientManager= clientManager;
        int labelX = 20;
        int labelY= 10;
        int textX = 70;

        JPanel contentPanel = new JPanel();
        //contentPanel.setSize(600,400);
        //contentPanel.setLayout(null);

        // 제목 입력
        JLabel titleLabel = new JLabel("아이템 제목:");
        titleLabel.setBounds( labelX, labelY, 70, 30);
        JTextField titleField = new JTextField();
        titleField.setBounds( textX, labelY, 200, 30);
        contentPanel.add(titleLabel );
        contentPanel.add(titleField );
        // 작성자
        labelY = 50;
        JLabel writerLabel = new JLabel("작성자:");
        writerLabel.setBounds( labelX, labelY, 70, 30);
        JTextField authorField = new JTextField();
        authorField.setBounds( textX, labelY, 200, 30);
        contentPanel.add(writerLabel );
        contentPanel.add(authorField );
        labelY = 90;
        TextArea txtArea = new TextArea();
        //txtArea.setBounds(labelX, labelX, 200, 200 );
        JScrollPane jScrollPane = new JScrollPane(txtArea,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
        jScrollPane.setBounds(textX, labelY, 400, 200 );
        contentPanel.add( jScrollPane);
    }
}
