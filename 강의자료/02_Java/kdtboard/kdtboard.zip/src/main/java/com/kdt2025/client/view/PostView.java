package com.kdt2025.client.view;

import com.kdt2025.client.controller.ClientManager;
import com.kdt2025.client.handler.PostActionHandler;
import com.kdt2025.common.dto.PostDto;

import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class PostView extends JPanel {
    JTextField titleField;
    JTextField authorField;
    JTextArea contentArea;

    public JButton btnAdd, btnCancle;

    public ClientManager clientManager;
    public PostView(ClientManager clientManager) {
        this.clientManager= clientManager;
        int labelX = 20;
        int labelY= 10;
        int textX = 70;
        //JPanel contentPanel = new JPanel();
        //contentPanel.setSize(500,400);
        //setLocation(0,0);
        //contentPanel.setLayout(null);
        setLayout(null);

        // 제목 입력
        JLabel titleLabel = new JLabel("제목:");
        titleLabel.setBounds( labelX, labelY, 70, 30);
        titleField = new JTextField();
        titleField.setBounds( textX, labelY, 200, 30);
        add(titleLabel );
        add(titleField );
        // 작성자
        labelY = 50;
        JLabel writerLabel = new JLabel("작성자:");
        writerLabel.setBounds( labelX, labelY, 70, 30);
        authorField = new JTextField();
        authorField.setBounds( textX, labelY, 200, 30);
        add(writerLabel );
        add(authorField );
        labelY = 90;
        contentArea = new JTextArea(100,30);
        contentArea.setBounds(textX, labelY, 400, 200 );
        //JScrollPane jScrollPane = new JScrollPane(contentArea );
        //jScrollPane.setBounds(textX, labelY, 400, 100 );
        add( contentArea);


        //JPanel btnPanel = new JPanel();
        btnAdd = new JButton("글쓰기");
        btnAdd.setBounds( 180, 300, 100,30);
        btnAdd.addActionListener(new PostActionHandler(this));
        btnCancle = new JButton("취소");
        btnCancle.setBounds(300, 300, 100, 30);
        btnCancle.addActionListener(new PostActionHandler(this));
        add(btnAdd);
        add(btnCancle);
        //add( btnPanel);
       //add(contentPanel);

    }
    public PostDto getPostDto(){
        PostDto postDto = new PostDto();
       //postDto.setId( );
        postDto.setWriter( authorField.getText());
        postDto.setTitle(titleField.getText());
        postDto.setContent( contentArea.getText() );
        LocalDateTime now = LocalDateTime.now();
        String formatedNow = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        postDto.setDate( formatedNow);
        return postDto;
    }
}
