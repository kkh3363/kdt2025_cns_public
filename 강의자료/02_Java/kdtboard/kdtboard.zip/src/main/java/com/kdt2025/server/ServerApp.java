package com.kdt2025.server;

import com.kdt2025.server.controller.ServerManager;

public class ServerApp {
    public static void main(String[] args) {
        ServerManager svrManager = new ServerManager();
    }

}
