package com.kdt2025.client.handler;

import com.kdt2025.client.view.ListView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ListActionHandler implements ActionListener {
    ListView listView;
    public ListActionHandler(ListView listView) {
        this.listView = listView;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if ( e.getSource() == listView.btnAdd){
            listView.clientManager.changePanel("write");
        }else if ( e.getSource() == listView.btnView){
            listView.clientManager.changePanel("view");
        }
    }


}
