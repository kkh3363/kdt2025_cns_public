package com.kdt2025.client.view;

import com.kdt2025.client.controller.ClientManager;

import javax.swing.*;
import java.awt.*;


public class ClientMainView extends JFrame {

    ClientManager clientManager;
    JPanel contentPanel;
    public CardLayout cardLayout;
    private JPanel cardPanel;

    public ClientMainView(ClientManager clientManager) throws HeadlessException {
        this.clientManager = clientManager;
        setTitle("자바 스윙 게시판");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //setLayout(  new BorderLayout());
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        cardPanel.add( new ListView(clientManager), "list");
        cardPanel.add( new PostView(clientManager), "write");
        cardPanel.add( new ItemView( clientManager), "view");
//        if (contentPanel == null ) {
//            //contentPanel = new ListView();
//            contentPanel = new WriteView();
//            contentPanel.setBounds(0,0, 500,350);
//            add( contentPanel , BorderLayout.CENTER);
//
//        }
        cardLayout.show( cardPanel, "write");
        add(cardPanel);

        setVisible(true);

    }
    public void changePanel(String strPanel){
        cardLayout.show(cardPanel, strPanel);
        //repaint();
    }

}
