package com.kdt2025.client.handler;

import com.kdt2025.client.view.PostView;
import com.kdt2025.common.dto.PostDto;
import com.kdt2025.common.json.jsonadaptor.CommMessageAdaptor;
import com.kdt2025.common.json.jsonadaptor.ItemMessageAdaptor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PostActionHandler implements ActionListener {
    PostView parentView;
    public PostActionHandler(PostView parentView) {
        this.parentView = parentView;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ( e.getSource() == parentView.btnCancle){
            parentView.clientManager.changePanel("list");
        }else if ( e.getSource() == parentView.btnAdd){
            PostDto dto = parentView.getPostDto();
            ItemMessageAdaptor itemAdaptor = new ItemMessageAdaptor();

            CommMessageAdaptor adaptor = new CommMessageAdaptor("post","new");
            adaptor.setData(  itemAdaptor.convertDtoToJson(dto) );
            System.out.println(adaptor.getJson());
           //parentView.clientManager.
        }
    }
}
