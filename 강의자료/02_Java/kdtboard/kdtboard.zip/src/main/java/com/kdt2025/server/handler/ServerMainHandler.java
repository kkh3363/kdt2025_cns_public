package com.kdt2025.server.handler;

import com.kdt2025.server.controller.ServerManager;
import com.kdt2025.server.view.ServerMainView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ServerMainHandler implements ActionListener {
    ServerMainView view;
    ServerManager svrControl;
    public ServerMainHandler(ServerMainView view, ServerManager svrControl) {
        this.view = view;
        this.svrControl = svrControl;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==view.btnstartServer){
            //view.appendTextLog("서버를 시작합니다 ");
            svrControl.startServer();
        }else if(e.getSource()==view.btnstop){
            view.appendTextLog("서버를 중지합니다 ");
            svrControl.stopServer();
        }
    }

}
