package com.kdt2025.common.json.jsonadaptor;

import com.kdt2025.common.json.jsondto.CommMessageDto;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;

import java.io.IOException;

public class CommMessageAdaptor {
    CommMessageDto msgDto ;
    Moshi moshi;
    JsonAdapter<CommMessageDto> msgAdaptor;
    public CommMessageAdaptor() {
        moshi = new Moshi.Builder().build();
        msgAdaptor = moshi.adapter(CommMessageDto.class);
        msgDto = new CommMessageDto();
    }
    public CommMessageAdaptor(String str) {
        this();
        if ( str !=null && !str.isEmpty() )
            msgDto = convertJsonToDto(str);
    }
    public CommMessageAdaptor(String strCommand, String strType) {
        this();
        if ( strCommand !=null && !strCommand.isEmpty() )
            msgDto.setCommand(strCommand);
        if ( strCommand !=strType && !strType.isEmpty() )
            msgDto.setType(strType);
    }
    /**
     *
     * @return
     */
    public CommMessageDto convertJsonToDto(String jsonString){
        CommMessageDto msgJson;
        try {
            msgJson = msgAdaptor.fromJson(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return msgJson;
    }
    public String convertDtoToJson(CommMessageDto tempDto){
        return msgAdaptor.toJson(tempDto);
    }

    public void cleanDto(){
        msgDto.setCommand("");
        msgDto.setData("");
    }
    public void setCommand(String str){ msgDto.setCommand(str); }
    public String getCommand(){ return msgDto.getCommand(); }

    public void setData(String strData){
        msgDto.setData(strData);
    }
    public String getJson(){
        return msgAdaptor.toJson(msgDto);
    }


    /**
     *
     * @return
     */
    public CommMessageDto getMsgDto() {
        return msgDto;
    }
}
