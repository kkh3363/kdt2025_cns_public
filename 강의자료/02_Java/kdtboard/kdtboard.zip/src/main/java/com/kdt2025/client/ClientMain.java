package com.kdt2025.client;

import com.kdt2025.client.controller.ClientManager;

public class ClientMain {
    public static void main(String[] args) {
        ClientManager clientManager= new ClientManager();
        clientManager.start();
    }
}
