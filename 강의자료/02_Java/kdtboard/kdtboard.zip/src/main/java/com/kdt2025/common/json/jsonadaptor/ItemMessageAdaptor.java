package com.kdt2025.common.json.jsonadaptor;

import com.kdt2025.common.dto.PostDto;
import com.kdt2025.common.json.jsondto.CommMessageDto;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;

import java.io.IOException;

public class ItemMessageAdaptor {
    PostDto msgDto ;
    Moshi moshi;
    JsonAdapter<PostDto> msgAdaptor;
    public ItemMessageAdaptor() {
        moshi = new Moshi.Builder().build();
        msgAdaptor = moshi.adapter(PostDto.class);
        msgDto = new PostDto();
    }
    public ItemMessageAdaptor(String str) {
        this();
        if ( str !=null && !str.isEmpty() )
            msgDto = convertJsonToDto(str);
    }
    /**
     *
     * @return
     */
    public PostDto convertJsonToDto(String jsonString){
        PostDto msgJson;
        try {
            msgJson = msgAdaptor.fromJson(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return msgJson;
    }
    public String convertDtoToJson(PostDto tempDto){
        return msgAdaptor.toJson(tempDto);
    }

    public void setJSonToDto(String strData){
        this.msgDto = convertJsonToDto(strData);

    }
    public String getJson(){
        return msgAdaptor.toJson(msgDto);
    }


    /**
     *
     * @return
     */
    public PostDto getMsgDto() {
        return msgDto;
    }
}
