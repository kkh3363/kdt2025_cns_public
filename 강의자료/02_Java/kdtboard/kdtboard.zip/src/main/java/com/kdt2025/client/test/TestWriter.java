package com.kdt2025.client.test;

import javax.swing.*;
import java.awt.*;

class SubPanel extends  JPanel {
    SubPanel(){
        setLayout( null);
        int labelX = 20;
        int labelY= 10;
        int textX = 70;
        setBounds(0,0, 600,400);
        // 제목 입력
        JLabel titleLabel = new JLabel("제목:");
        titleLabel.setBounds( labelX, labelY, 70, 30);
        JTextField titleField = new JTextField();
        titleField.setBounds( textX, labelY, 200, 30);
        add(titleLabel );
        add(titleField );
        // 작성자
        labelY = 50;
        JLabel writerLabel = new JLabel("작성자:");
        writerLabel.setBounds( labelX, labelY, 70, 30);
        JTextField authorField = new JTextField();
        authorField.setBounds( textX, labelY, 200, 30);
        add(writerLabel );
        add(authorField );
        labelY = 90;
        TextArea txtArea = new TextArea();
        //txtArea.setBounds(labelX, labelX, 200, 200 );
        JScrollPane jScrollPane = new JScrollPane(txtArea,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
        jScrollPane.setBounds(textX, labelY, 400, 200 );
        add( jScrollPane);


        //add(contentPanel);
    }
}
public class TestWriter extends JFrame {
    TestWriter(){
        Dimension dim = new Dimension(400, 10);
        setTitle("자바 스윙 게시판");
        setLocationRelativeTo(null);
        setSize(600, 400);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        if ( false) {
            JPanel contentPanel = new JPanel();
            contentPanel.setLayout(null);
            int labelX = 20;
            int labelY = 10;
            int textX = 70;
            // 제목 입력
            //JPanel titlePanel = new JPanel(new BorderLayout());
            JLabel titleLabel = new JLabel("제목:");
            titleLabel.setBounds(labelX, labelY, 70, 30);
            JTextField titleField = new JTextField();
            titleField.setBounds(textX, labelY, 200, 30);
            contentPanel.add(titleLabel);
            contentPanel.add(titleField);
            // 작성자
            labelY = 50;
            JLabel writerLabel = new JLabel("작성자:");
            writerLabel.setBounds(labelX, labelY, 70, 30);
            JTextField authorField = new JTextField();
            authorField.setBounds(textX, labelY, 200, 30);
            contentPanel.add(writerLabel);
            contentPanel.add(authorField);
            labelY = 90;
            TextArea txtArea = new TextArea();
            //txtArea.setBounds(labelX, labelX, 200, 200 );
            JScrollPane jScrollPane = new JScrollPane(txtArea,
                    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                    JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            jScrollPane.setBounds(textX, labelY, 400, 200);
            contentPanel.add(jScrollPane);

            //setContentPane( new SubPanel());
            add(contentPanel);
        }
        else
            add(new SubPanel());

        setVisible(true);
    }
    public static void main(String[] args) {
        TestWriter testWriter = new TestWriter();
    }
}
