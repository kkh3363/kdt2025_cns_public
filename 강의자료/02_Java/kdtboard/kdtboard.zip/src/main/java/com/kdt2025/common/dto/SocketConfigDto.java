package com.kdt2025.common.dto;

public class SocketConfigDto {
    private int portNumber;

}
